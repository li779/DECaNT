#include <iostream>
#include <cmath>
#include <algorithm>

#include "scatter.h"

namespace mc
{

} // mc namespace
