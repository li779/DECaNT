#include <iostream>

#include "region.h"

namespace mc
{

} // mc namespace
